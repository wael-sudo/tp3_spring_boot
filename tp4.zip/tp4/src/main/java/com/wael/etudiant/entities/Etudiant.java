package com.wael.etudiant.entities;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Etudiant {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@ManyToOne
private Section section;
private Long id;
private String nom;
private Double moyenne;
private Date dateNaissance;
public Etudiant() {
super();
}
public Etudiant (String nom, Double moyenne, Date dateNaissance) {
super();
this.nom = nom;
this.moyenne = moyenne;
this.dateNaissance= dateNaissance;
}

public Long getId() {
return id;
}
public void setId(Long id) {
this.id = id;
}
public String getNom() {
return nom;
}
public void setNom(String nom) {
this.nom = nom;
}
public Double getMoyenne() {
return moyenne;
}
public void setMoyenne(Double moyenne) {
this.moyenne = moyenne;
}
public Date getDateNaissance() {
return dateNaissance;
}
public void setDateCreation(Date dateNaissance) {
this.dateNaissance = dateNaissance;
}
@Override
public String toString() {
return "Produit [id=" + id+ ", nom=" + nom+ ", moyenne=" + moyenne
+ ", dateNaissance=" + dateNaissance + "]";
}
}