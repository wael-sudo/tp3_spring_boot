package com.wael.etudiant.entities;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Section {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idSect;
	private String nomSect;
	private String descriptionSect;
	@JsonIgnore
	@OneToMany(mappedBy = "section")
	private List<Etudiant> etudiant;
	public Section(String nomSect, String descriptionSect, List<Etudiant> etudiant)
	{
	super();
	this.nomSect = nomSect;
	this.descriptionSect = descriptionSect;
	this.etudiant = etudiant;
	}
	public Long getIdSect() {
	return idSect;
	}
	public void setIdSect(Long idSect) {
	this.idSect = idSect;
	}
	public String getNomSect() {
	return nomSect;
	}
	public void setNomSect(String nomSect) {
	this.nomSect = nomSect;
	}
	public String getDescriptionSect() {
	return descriptionSect;
	}
	public void setDescriptionSect(String descriptionSect) {
	this.descriptionSect = descriptionSect;
	}
	public List<Etudiant> getEtudiant() {
	return etudiant;
	}
	public void setEtudiant(List<Etudiant> etudiant) {
	this.etudiant = etudiant;
	}
	

}

