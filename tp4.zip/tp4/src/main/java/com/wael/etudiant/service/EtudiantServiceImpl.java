package com.wael.etudiant.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.entities.Section;
import com.wael.etudiant.repos.EtudiantRepository;
@Service
public class EtudiantServiceImpl implements EtudiantService {
@Autowired EtudiantRepository EtudiantRepository;
@Override
public Etudiant saveEtudiant(Etudiant e) { return EtudiantRepository.save(e);
}
@Override
public Etudiant updateEtudiant(Etudiant e) {
	// TODO Auto-generated method stub
	return EtudiantRepository.save(e);
}
@Override
public void deleteEtudiant(Etudiant e) {
	// TODO Auto-generated method stub
	EtudiantRepository.delete(e);
	
}
@Override
public void deleteEtudiantById(Long id) {
	// TODO Auto-generated method stub
	EtudiantRepository.deleteById(id);
}
@Override
public Etudiant getEtudiant(Long id) {
	// TODO Auto-generated method stub
	return EtudiantRepository.findById(id).get();
}
@Override
public List<Etudiant> getAllEtudiant() {
	// TODO Auto-generated method stub
	return EtudiantRepository.findAll();
}
@Override
public Page<Etudiant> getAllEtudiantParPage(int page, int size) {
	return EtudiantRepository.findAll(PageRequest.of(page, size));
}
@Override
public List<Etudiant> findByNomEtudiant(String nom) {
	// TODO Auto-generated method stub
	return  EtudiantRepository.findByNomEtudiant(nom);
}
@Override
public List<Etudiant> findByNomEtudiantContains(String nom) {
	// TODO Auto-generated method stub
	return EtudiantRepository.findByNomEtudiantContains(nom);

}
@Override
public List<Etudiant> findByNomMoyenne(String nom, Double moyenne) {
	// TODO Auto-generated method stub
	return EtudiantRepository.findByNomMoyenne(nom, moyenne);
}
@Override
public List<Etudiant> findBySection(Section section) {
	// TODO Auto-generated method stub
	return EtudiantRepository.findBySection(section);
}
@Override
public List<Etudiant> findBySectionIdSect(Long id) {
	// TODO Auto-generated method stub
	return EtudiantRepository.findBySectionidSect(id);
}
@Override
public List<Etudiant> findByOrderByNomEtudiantAsc() {
	// TODO Auto-generated method stub
	return EtudiantRepository.findByOrderByNomEtudiantAsc();
}
@Override
public List<Etudiant> trierEtudiantNomsMoyenne() {
	// TODO Auto-generated method stub
	return EtudiantRepository.trierEtudiantNomsMoyenne();
}

}