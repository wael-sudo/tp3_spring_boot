package com.wael.etudiant.controllers;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.service.EtudiantService;
@Controller
public class EtudiantController {
	@Autowired
	EtudiantService  EtudiantService;
	@RequestMapping("/showCreate")
	public String showCreate()
	{
	return "createEtudiant";
	}
	@RequestMapping("/saveEtudiant")
	public String saveEtudiant(@ModelAttribute("etudiant") Etudiant etudiant,
	@RequestParam("date") String date,
	ModelMap modelMap) throws ParseException
	{
	
	SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
	Date dateNaissance = dateformat.parse(String.valueOf(date)); etudiant.setDateCreation(dateNaissance);
	Etudiant saveEtudiant = EtudiantService.saveEtudiant(etudiant);
	String msg ="etudiant enregistré avec Id "+saveEtudiant.getId();
	modelMap.addAttribute("msg", msg);
	return "createEtudiant";
	}
	@RequestMapping("/ListeEtudiant")
	public String listEtudiant(ModelMap modelMap,
	@RequestParam (name="page",defaultValue = "0") int page,
	@RequestParam (name="size", defaultValue = "2") int size)
	{ Page<Etudiant> etuds = EtudiantService.getAllEtudiantParPage(page, size);
	modelMap.addAttribute("etudiant", etuds);
	modelMap.addAttribute("pages", new int[etuds.getTotalPages()]);
	modelMap.addAttribute("currentPage", page);
	return "listeEtudiant";
	}
	@RequestMapping("/supprimerEtudiant") public String supprimerEtudiant(@RequestParam("id") Long id,
			ModelMap modelMap,
			@RequestParam (name="page",defaultValue = "0") int page,
			@RequestParam (name="size", defaultValue = "2") int size)
			{
			EtudiantService.deleteEtudiantById(id);
			Page<Etudiant> etuds = EtudiantService.getAllEtudiantParPage(page, size);
			modelMap.addAttribute("etudiant", etuds);
			modelMap.addAttribute("pages", new int[etuds.getTotalPages()]);
			modelMap.addAttribute("currentPage", page);
			modelMap.addAttribute("size", size);
			return "listeEtudiant";
			}
	@RequestMapping("/modifierEtudiant")
	public String editerEtudiant(@RequestParam("id") Long id,ModelMap modelMap)
	{
	Etudiant e= EtudiantService.getEtudiant(id);
	modelMap.addAttribute("etudiant", e);
	return "editerEtudiant";
	}
	@RequestMapping("/updateEtudiant")
	public String updateEtudiant(@ModelAttribute("etudiant") Etudiant etudiant,
	@RequestParam("date") String date,ModelMap modelMap) throws ParseException
	{
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateNaissance = dateformat.parse(String.valueOf(date));
		etudiant.setDateCreation(dateNaissance);
		EtudiantService.updateEtudiant(etudiant);
		List<Etudiant> etuds = EtudiantService.getAllEtudiant();
		modelMap.addAttribute("etudiant", etuds);
		return "listeEtudiant";
		}
}

