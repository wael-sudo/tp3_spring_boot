package com.wael.etudiant.service;
import java.util.List;

import org.springframework.data.domain.Page;

import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.entities.Section;
public interface EtudiantService {
	Page<Etudiant> getAllEtudiantParPage(int page, int size);
	Etudiant saveEtudiant(Etudiant e);
	Etudiant updateEtudiant(Etudiant p);
	void deleteEtudiant(Etudiant p);
	void deleteEtudiantById(Long id);
	Etudiant getEtudiant(Long id);
	List<Etudiant> getAllEtudiant();
	List<Etudiant> findByNomEtudiant(String nom);
	List<Etudiant> findByNomEtudiantContains(String nom);
	List<Etudiant> findByNomMoyenne (String nom, Double moyenne);
	List<Etudiant> findBySection (Section section);
	List<Etudiant> findBySectionIdSect(Long id);
	List<Etudiant> findByOrderByNomEtudiantAsc();
	List<Etudiant> trierEtudiantNomsMoyenne();
}
