package com.wael.etudiant.repos;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.entities.Section;
public interface EtudiantRepository extends JpaRepository<Etudiant, Long> {

		
		List<Etudiant> findByNomEtudiant(String nom);
		 List<Etudiant> findByNomEtudiantContains(String nom);
		 @Query("select e from Etudiantp where e.nom like %?1 and e.moyenne > ?2")
		 List<Etudiant> findByNomMoyenne (String nom, Double prix);
		 @Query("select e from Etudiant e where  e.Section = ?1")
		 List<Etudiant> findByCategorie (Section section);
		 List<Etudiant> findBySectionIdSect(Long id);
		 @Query("select e from Etudiant e order by e.nom ASC, e.moyenne DESC")
		 List<Etudiant> trierEtudiantNomsMoyenne ();

		 	
	

	


}
