package com.wael.etudiant;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.repos.EtudiantRepository;
import com.wael.etudiant.service.EtudiantService;

@SpringBootApplication
public class EtudiantApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EtudiantApplication.class, args);
	}
	
	@Autowired
	EtudiantService etudiantService;
	
	@Override
	public void run(String... args) throws Exception {
	etudiantService.saveEtudiant(new Etudiant("fadi", 6.5, new Date()));
	etudiantService.saveEtudiant(new Etudiant("sami", 8.0, new Date()));
	etudiantService.saveEtudiant(new Etudiant("helmi", 9.9, new Date()));
	}
	
}
