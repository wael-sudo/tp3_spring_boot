package com.wael.etudiant;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.wael.etudiant.entities.Etudiant;
import com.wael.etudiant.repos.EtudiantRepository;
import com.wael.etudiant.service.EtudiantService;
@SpringBootTest
class EtudiantApplicationTests {
	@Autowired
	private EtudiantRepository EtudiantRepository;
	@Autowired
	private EtudiantService etudiantService;
@Test
public void testCreateEtudiant() {
Etudiant prod = new Etudiant("wael",14.5,new Date());
EtudiantRepository.save(prod);
}

@Test
public void testFindEtudiant()
{ Etudiant e = EtudiantRepository.findById(1L).get(); System.out.println(e);
}
@Test
public void testUpdateProduit()
{ Etudiant e = EtudiantRepository.findById(1L).get();
e.setMoyenne(16.0); EtudiantRepository.save(e);
}
@Test
public void testDeleteEtudiant() {

	EtudiantRepository.deleteById(1L);;


}

@Test
public void testListerTousEtudiant()
{
List<Etudiant> etuds = EtudiantRepository.findAll();
for (Etudiant e : etuds)
{
System.out.println(e);
}
}
@Test
public void testFindByNomEtudiantContains()
{
Page<Etudiant> etuds = etudiantService.getAllEtudiantParPage(0,2);
System.out.println(etuds.getSize());
System.out.println(etuds.getTotalElements()); System.out.println(etuds.getTotalPages());
etuds.getContent().forEach(p -> {System.out.println(p.toString());
});
/*ou bien
for (Produit p : prods)
{
System.out.println(p);
} */
}
@Test
public void testFindByNomEtudiant()
{
List<Etudiant> etuds = EtudiantRepository.findByNomEtudiant("sami");
for (Etudiant e : etuds)
{
System.out.println(e);
}
}
@Test
public void testfindByNomPrix()
{
List<Etudiant> etuds = EtudiantRepository.findByNomMoyenne("fadi", 6.5);
for (Etudiant e : etuds)
{
System.out.println(e);
}
}



}
